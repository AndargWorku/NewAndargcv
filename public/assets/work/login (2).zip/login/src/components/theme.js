// theme.js

import { extendTheme } from "@chakra-ui/react";

const theme = extendTheme({
  colors: {
    blackWhite: {
      bg: "#000000",
      text: "#FFFFFF",
    },
    // Add more custom colors here if needed
  },
  components: {
    Button: {
      baseStyle: {
        width: "200px", // Custom width
        height: "30px", // Custom height
      },
    },
  
    Input: {
      baseStyle: {
        width: "100px", 
        height: "40px", 
        borderRadius: "md", 
        borderColor: "gray.200", 
        borderWidth: "1px", 
        px: "4", 
        py: "3", 
        fontSize: "md", 
      },
    },
  },
});

export default theme;
