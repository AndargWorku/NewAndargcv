


import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ThemeProvider } from "@chakra-ui/react";
import theme from "./theme";
import { login, logout } from "../redux/actions/authActions";
import {
  Box,
  Flex,
  Image,
  Input,
  Button,
  Stack,
  Text,
  Link,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  
  ModalBody,
  ModalCloseButton,
} from "@chakra-ui/react";
import { FaFacebookF } from "react-icons/fa";
import { FcGoogle } from "react-icons/fc";

import k from "../images/k.jpg";

const Login = () => {
  const dispatch = useDispatch();
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [facebookToken, setFacebookToken] = useState(
    localStorage.getItem("facebookAccessToken")
  );
  const [googleToken, setGoogleToken] = useState(
    localStorage.getItem("googleAccessToken")
  );
  const [emailErrorModalOpen, setEmailErrorModalOpen] = useState(false);
  const [passwordErrorModalOpen, setPasswordErrorModalOpen] = useState(false);
  const [bothErrorModalOpen, setBothErrorModalOpen] = useState(false);

  const handleLoginWithEmail = () => {
    if (!email && !password) {
      setBothErrorModalOpen(true);
    } else if (!email) {
      setEmailErrorModalOpen(true);
    } else if (!password) {
      setPasswordErrorModalOpen(true);
    } else {
      // Sample implementation for email and password authentication
      // Assuming successful authentication
      const accessToken = "sample_access_token_email"; // Example token
      localStorage.setItem("accessToken", accessToken);
      dispatch(login());
    }
  };

  const handleLoginWithProvider = (provider) => {
    if (provider === "facebook") {
      // Sample implementation for Facebook login
      // Assuming successful authentication
      const facebookAccessToken = "sample_access_token_facebook"; // Example token
      localStorage.setItem("facebookAccessToken", facebookAccessToken);
      setFacebookToken(facebookAccessToken);
      dispatch(login());
    } else if (provider === "google") {
      // Sample implementation for Google login
      // Assuming successful authentication
      const googleAccessToken = "sample_access_token_google"; // Example token
      localStorage.setItem("googleAccessToken", googleAccessToken);
      setGoogleToken(googleAccessToken);
      dispatch(login());
    }
  };

  const handleLogout = () => {
    // Clear tokens from local storage and dispatch logout action
    localStorage.removeItem("accessToken");
    localStorage.removeItem("facebookAccessToken");
    localStorage.removeItem("googleAccessToken");
    dispatch(logout());
  };

  return (
    <ThemeProvider theme={theme}>
      <Flex height="100vh" alignItems="center" justifyContent="center">
        <Box
          width="80vw"
          boxShadow="0 0 30px rgba(0, 0, 0, 0.5)"
          borderRadius="xl"
          bg="white"
        >
          <Flex>
            <Box flex="1" p="8" borderRadius="xl">
              <Flex
                direction="column"
                justify="center"
                align="center"
                height="100%"
              >
                <Text fontSize="3xl" mb="4" fontWeight="bold">
                  Welcome Back!
                </Text>

                {isLoggedIn ? (
                  <Button
                    bg="blackWhite.bg"
                    color="blackWhite.text"
                    width="100%"
                    height="40px"
                    rounded="xl"
                    size="sm"
                    onClick={handleLogout}
                  >
                    Logout
                  </Button>
                ) : (
                  <Stack spacing="1" width="80%">
                    <Text fontSize="md" mb="1">
                      Email
                    </Text>
                    <Input
                      placeholder="Enter email"
                      rounded="md"
                      mb="2"
                      height="30px"
                      width="310px"
                      borderRadius="md"
                      borderColor="gray.200"
                      borderWidth="1px"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  
                    <Text fontSize="md" mb="1">
                      Password
                    </Text>
                    <Input
                      placeholder="Enter password"
                      type="password"
                      rounded="md"
                      mb="2"
                      height="30px"
                      width="310px"
                      borderRadius="md"
                      borderColor="gray.200"
                      borderWidth="1px"
                      fontSize="md"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />

                    <Link alignSelf="flex-end" color="blue.500" fontSize="sm">
                      Forgot Password?
                    </Link>
                    <Button
                      bg="blackWhite.bg"
                      color="blackWhite.text"
                      width="100%"
                      height="40px"
                      rounded="xl"
                      size="sm"
                      onClick={handleLoginWithEmail}
                    >
                      Login
                    </Button>
                    <Text align="center"> or</Text>

                    <Flex align="center" justify="center" gap={4}>
                      <Button
                        leftIcon={<FaFacebookF />}
                        mr="2"
                        rounded="xl"
                        borderRadius="md"
                        borderColor="gray.200"
                        borderWidth="1px"
                        fontSize="md"
                        onClick={() => handleLoginWithProvider("facebook")}
                      >
                        Facebook
                      </Button>
                      <Button
                        leftIcon={<FcGoogle />}
                        borderRadius="xl"
                        borderColor="gray.200"
                        borderWidth="1px"
                        fontSize="md"
                        onClick={() => handleLoginWithProvider("google")}
                      >
                        Google
                      </Button>
                    </Flex>

                    <Text mt="4" align="center">
                      Don't have an account?{" "}
                    </Text>
                    <Button
                      borderRadius="md"
                      width="100%"
                      borderColor="gray.200"
                      borderWidth="1px"
                      fontSize="md"
                    >
                      <Link color="blue.500">Sign Up</Link>
                    </Button>
                  </Stack>
                )}
              </Flex>
            </Box>
            <Box flex="2" position="relative">
              <Image
                src={k}
                alt="Background"
                objectFit="cover"
                width="100%"
                height="100%"
                borderRadius="xl"
              />
              <Text
                position="absolute"
                bottom="4"
                left="4"
                color="white"
                fontSize="2xl"
              >
                If you want anything login
              </Text>
            </Box>
          </Flex>
        </Box>
      </Flex>

      <Modal isOpen={emailErrorModalOpen} onClose={() => setEmailErrorModalOpen(false)}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Error</ModalHeader>
          <ModalCloseButton
            bg="black"
            color="white"
            size="sm"
            position="absolute"
            top="0"
            right="0"
            mt="2"
            mr="2"
          />
          <ModalBody>
            <Text>Please enter your email.</Text>
          </ModalBody>

          
        </ModalContent>
      </Modal>

      <Modal isOpen={passwordErrorModalOpen} onClose={() => setPasswordErrorModalOpen(false)}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Error</ModalHeader>
          <ModalCloseButton
            bg="black"
            color="white"
            size="sm"
            position="absolute"
            top="0"
            right="0"
            mt="2"
            mr="2"
          />
          <ModalBody>
            <Text>Please enter your password.</Text>
          </ModalBody>

          
        </ModalContent>
      </Modal>

      <Modal isOpen={bothErrorModalOpen} onClose={() => setBothErrorModalOpen(false)}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Error</ModalHeader>
          <ModalCloseButton
            bg="black"
            color="white"
            size="sm"
            position="absolute"
            top="0"
            right="0"
            mt="2"
            mr="2"
          />
          <ModalBody>
            <Text>Please enter your email and password.</Text>
          </ModalBody>

          
        </ModalContent>
      </Modal>
    </ThemeProvider>
  );
};

export default Login;


