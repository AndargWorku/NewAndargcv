// authReducer.js

const initialState = {
    isLoggedIn: localStorage.getItem('isLoggedIn') === 'true',
  };
  
  const authReducer = (state = initialState, action) => {
    switch (action.type) {
      case 'LOGIN':
        localStorage.setItem('isLoggedIn', 'true');
        return { ...state, isLoggedIn: true };
      case 'LOGOUT':
        localStorage.setItem('isLoggedIn', 'false');
        return { ...state, isLoggedIn: false };
      default:
        return state;
    }
  };
  
  export default authReducer;
  