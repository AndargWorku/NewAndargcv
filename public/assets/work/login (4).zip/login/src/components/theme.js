

import { extendTheme } from "@chakra-ui/react";

const theme = extendTheme({
  colors: {
    blackWhite: {
      bg: "#000000",
      text: "#FFFFFF",
    },
    
  },
  components: {
    Button: {
      baseStyle: {
        width: "200px", 
        height: "30px", 
      },
    },
  
    Input: {
      baseStyle: {
        width: "100px", 
        height: "40px", 
        borderRadius: "md", 
        borderColor: "gray.200", 
        borderWidth: "1px", 
        px: "4", 
        py: "3", 
        fontSize: "md", 
      },
    },
  },
});

export default theme;
