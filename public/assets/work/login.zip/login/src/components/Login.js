

// import React from "react";
// import { ThemeProvider } from "@chakra-ui/react";
// import theme from "./theme"; // Import your custom theme

// import {
//   Box,
//   Flex,
//   Image,
//   Input,
//   Button,
//   Stack,
//   Text,
//   Link,
// } from "@chakra-ui/react";
// import { FaFacebookF } from "react-icons/fa";
// import { FcGoogle } from "react-icons/fc";

// import k from "../images/k.jpg";

// const Login = () => {
//   return (
//     <ThemeProvider theme={theme}>
//       <Flex height="100vh" alignItems="center" justifyContent="center">
//         <Box
//           width="80vw"
//           boxShadow="0 0 30px rgba(0, 0, 0, 0.5)" // Very extra large box shadow
//           borderRadius="xl"
//           bg="white" // Set background color to pure white
//         >
//           <Flex>
//             {/* Login Section */}
//             <Box flex="1" p="8" borderRadius="xl">
//               <Flex
//                 direction="column"
//                 justify="center"
//                 align="center"
//                 height="100%"
//               >
//                 <Text fontSize="3xl" mb="4" fontWeight="bold">
//                   Welcome Back!
//                 </Text>

//                 <Stack spacing="1" width="80%">
//                   <Text fontSize="md" mb="1">
//                     Email
//                   </Text>
//                   <Input placeholder="Enter Email" rounded="md" mb="2" height="30px"  
//                   borderRadius="md"
//                   borderColor="gray.200"
//                   borderWidth="1px"
                  
//                   fontSize="md"/>

//                   <Text fontSize="md" mb="1">
//                     Password
//                   </Text>
//                   <Input
//                     placeholder="Enter Password"
//                     type="password"
//                     rounded="md"
//                     mb="2"
                    
//                     borderRadius="md"
//                     borderColor="gray.200"
//                     borderWidth="1px"
                    
//                     fontSize="md"
                   
//                   />

//                   <Link alignSelf="flex-end" color="blue.500" fontSize="sm">
//                     Forgot Password?
//                   </Link>
//                   <Button
//                     bg="blackWhite.bg"
//                     color="blackWhite.text"
//                     width="100%"
//                     height="40px"
//                     rounded="xl"
//                     size="sm"
//                   >
//                     Login
//                   </Button>

//                   <Text align="center"> or</Text>
//                   <Flex align="center" justify="center" gap={4}>
//                     <Button leftIcon={<FaFacebookF />} mr="2" rounded="xl"
//                     borderRadius="md"
//                     borderColor="gray.200"
//                     borderWidth="1px"
                    
//                     fontSize="md">
//                       Facebook
//                     </Button>
//                     <Button leftIcon={<FcGoogle />} borderRadius="xl" 
//                     borderColor="gray.200"
//                     borderWidth="1px"
                    
//                     fontSize="md">
//                       Google
//                     </Button>
//                   </Flex>
//                   <Text mt="4" align="center">Don't have an account? </Text>
//                   <Button borderRadius="md" width="100%" 
//                     borderColor="gray.200"
//                     borderWidth="1px"
                    
//                     fontSize="md">
//                     <Link color="blue.500">Sign Up</Link>
//                   </Button>
//                 </Stack>
//               </Flex>
//             </Box>

//             {/* Image Section */}
//             <Box flex="2" position="relative">
//               <Image
//                 src={k}
//                 alt="Background"
//                 objectFit="cover"
//                 width="100%"
//                 height="100%"
//                 borderRadius="xl"
//               />
//               <Text
//                 position="absolute"
//                 bottom="4"
//                 left="4"
//                 color="white"
//                 fontSize="xl"
//               >
//                 If you want anything login 
//               </Text>
//             </Box>
//           </Flex>
//         </Box>
//       </Flex>
//     </ThemeProvider>
//   );
// };

// export default Login;






